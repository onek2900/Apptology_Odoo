# -*- coding: utf-8 -*-
from . import deliverect_info_wizard