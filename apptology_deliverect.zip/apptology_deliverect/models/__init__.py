# -*- coding: utf-8 -*-
from . import res_config_settings
from . import deliverect_api
from . import deliverect_channel
from . import product_product
from . import deliverect_allergens
from . import pos_orders
from . import pos_config
from . import res_partner
from . import pos_payment_method
from . import pos_session
from . import deliverect_modifier_group
from . import deliverect_modifier_product_lines
from . import product_template
